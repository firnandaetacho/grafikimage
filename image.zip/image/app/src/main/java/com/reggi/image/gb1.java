package com.reggi.image;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.ImageView;

public class gb1 extends Activity {
    @Override
    public void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gb1);
    }
    public void tampil (View v) {
        ImageView gb1=(ImageView)findViewById(R.id.imageView);
        gb1.setImageResource(R.drawable.ball_small);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.gb1, menu);
        return true;
    }
}